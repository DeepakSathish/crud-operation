// const mongoose=require("mongoose");
// const express=require ("express");
// const app=express();
// // mongodb is database but moongose is usde to connect the db
// require("dotenv").config();
// // dotenv is used to config the hideen files
// const connectionparas ={
//     useNameUrLparser:true,
//     useCreateIndex:true,
//     useUnifieldTopology:true
// }
// const uri = "mongodb+srv://${ process.env.MANGO_USER}:${process.env.MANGO_PASSWORD}@cluster0.toal2av.mongodb.net/myblog?retryWrites=true&w=majority";
// const connexion=mongoose.connect(uri,connectionParams).then(()=> {console.log('connected to cloud clust')})
// .catch ((err)=>{console.log(err)});
// app.listen(3001 ,()=>{
//     console.log(" listeniing to 3001")
// })


// module.exports=connexion

const mongodb = require('mongodb');
const MongoClient = mongodb.MongoClient;
const ObjectID = mongodb.ObjectId;

let database;

async function getDatabase(){
    const client = await MongoClient.connect('mongodb+srv://deepak:deepak@cluster0.toal2av.mongodb.net/');
    database = client.db('library');

    if (!database) {
            console.log('Database not connected');
    }

    return database;
}

module.exports = {
    getDatabase,
    ObjectID
}
