// npm i express nodemon mongodb dotenv (to instal first)
// nmp init -y ..to show thedescription
// node-modules nama delete panitio marupadeum line one command kuduthu install pananum
// package .json laa script laa poi nodemon app.js kuduthu nama terminal la npm start kudutha run aagum
// const express=require ("express");
// const app=express();
// const db=require("mongo/connection.js");


// app.listen(3001 ,()=>{
//     console.log(" listeniing to 3001")pl;k
// })

const express = require('express');
const app = express();
const bodyparser = require('body-parser');
const exhbs = require('express-handlebars');
// const dbo = require('./connection');
// const ObjectID = dbo.ObjectID;
const mongodb = require('mongodb');
const MongoClient = mongodb.MongoClient;
const ObjectID = mongodb.ObjectId;

let database;

async function getDatabase(){
    const client = await MongoClient.connect('mongodb+srv://deepak:deepak@cluster0.toal2av.mongodb.net/');
    database = client.db('library');

    if (!database) {
            console.log('Database not connected');
    }

    return database;
}

app.engine('hbs',exhbs.engine({layoutsDir:'views/',defaultLayout:"main",extname:"hbs"}))
app.set('view engine','hbs');
app.set('views','views');
app.use(bodyparser.urlencoded({extended:true}));

app.get('/',async (req,res)=>{
    let database = await getDatabase();
    const collection = database.collection('books');
    const cursor = collection.find({})
    let books = await cursor.toArray();

    let message = '';
    let edit_id, edit_travel,travel;

    if(req.query.edit_id){
        edit_id = req.query.edit_id;
        edit_book = await collection.findOne({_id:new ObjectID(edit_id)})
    }

    if (req.query.delete_id) {
        await collection.deleteOne({_id:new ObjectID(req.query.delete_id)})
        return res.redirect('/?status=3');
    }
    
    switch (req.query.status) {
        case '1':
            message = 'Inserted Succesfully!';
            break;

        case '2':
            message = 'Updated Succesfully!';
            break;

        case '3':
            message = 'Deleted Succesfully!';
            break;
    
        default:
            break;
    }


    res.render('index',{message,travel,edit_id,edit_travel})
})

app.post('/store_travel',async (req,res)=>{
    let database = await dbo.getDatabase();
    const collection = database.collection('books');
    let book = { title: req.body.title, author: req.body.author  };
    await collection.insertOne(book);
    return res.redirect('/?status=1');
})

app.post('/update_travel/:edit_id',async (req,res)=>{
    let database = await dbo.getDatabase();
    const collection = database.collection('books');
    let book = { title: req.body.title, author: req.body.author  };
    let edit_id = req.params.edit_id;
    await collection.updateOne({_id:new ObjectID(edit_id)},{$set:book});
    return res.redirect('/?status=2');
})

app.listen(8000,()=>{console.log('Listening to 8000 port');})
